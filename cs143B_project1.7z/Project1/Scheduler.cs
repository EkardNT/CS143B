﻿namespace Project1
{
	public class Scheduler
	{
		public readonly Node<Process>[] readyList; 

		public Scheduler()
		{
			readyList = new Node<Process>[3];
		}

		public void Schedule()
		{
			
		}
	}
}