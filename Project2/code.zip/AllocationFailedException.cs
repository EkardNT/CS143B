﻿using System;

namespace Project2
{
	public class AllocationFailedException : Exception
	{
	}
}